//common_func.h

#ifndef _COMMON_FUNC_H
#define _COMMON_FUNC_H

#ifdef __cplusplus
extern "C" {
#endif

int my_daemon_init();

#ifdef __cplusplus
}
#endif

#endif
